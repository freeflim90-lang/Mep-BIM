"""Shared backend core utilities."""
